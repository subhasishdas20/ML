# Sales-Analysis-in-2019
using pandas , numpy, matplotlib, seaborn all libraries where analysis the different products which has most sold in year which is least sold which time has higest no of sold. 
1-Analysis Questions_

# 1-Best months for sales and how much was earned that month
# 2-City which has higest no of Sales
# 3-Which Time the advertisements should display so maximum customer is buying
# 4-Products are most often sold together
# 5-which product Sold the most and why?
